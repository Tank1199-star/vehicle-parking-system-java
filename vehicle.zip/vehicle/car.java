package advance_java;

class car extends vehicle {

    car(String vehicleNumber, String ownerName) {

        super(vehicleNumber, ownerName);
    }
}

