package advance_java;
import java.util.Scanner;

public class main_code {
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            parking_sys parking = new parking_sys();

            while (true) {

                System.out.println("\n--- Vehicle Parking System ---");
                System.out.println("1. Park Vehicle");
                System.out.println("2. Remove Vehicle");
                System.out.println("3. Display Vehicles");
                System.out.println("4. Available Slots");
                System.out.println("5. Exit");

                System.out.print("Enter Choice: ");
                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:

                        System.out.print("Vehicle Number: ");
                        String number = sc.nextLine();

                        System.out.print("Owner Name: ");
                        String owner = sc.nextLine();

                         car car = new car(number, owner);
                        parking.parkVehicle(car);
                        break;

                    case 2:

                        System.out.print("Enter Vehicle Number: ");
                        String removeNumber = sc.nextLine();

                        parking.removeVehicle(removeNumber);
                        break;

                    case 3:
                        parking.displayVehicles();
                        break;

                    case 4:
                        parking.availableSlots();
                        break;

                    case 5:
                        System.out.println("Thank You");
                        System.exit(0);

                    default:
                        System.out.println("Invalid Choice");
                }
            }
        }
    }
