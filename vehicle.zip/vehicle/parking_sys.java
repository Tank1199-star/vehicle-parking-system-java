package advance_java;
import java.util.ArrayList;

public class parking_sys {



        ArrayList<vehicle> vehicles = new ArrayList<>();
        int capacity = 5;

        void parkVehicle(vehicle v) {

            if (vehicles.size() < capacity) {
                vehicles.add(v);
                System.out.println("Vehicle Parked Successfully");
            } else {
                System.out.println("Parking Full");
            }
        }

        void removeVehicle(String vehicleNumber) {

            for (vehicle v : vehicles) {

                if (v.vehicleNumber.equals(vehicleNumber)) {
                    vehicles.remove(v);
                    System.out.println("Vehicle Removed");
                    return;
                }
            }

            System.out.println("Vehicle Not Found");
        }

        void displayVehicles() {

            if (vehicles.isEmpty()) {
                System.out.println("No Vehicles Parked");
                return;
            }

            for (vehicle v : vehicles) {
                v.display();
                System.out.println("----------------");
            }
        }

        void availableSlots() {
            System.out.println("Available Slots: "
                    + (capacity - vehicles.size()));
        }
    }

