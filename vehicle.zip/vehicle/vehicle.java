package advance_java;

public class vehicle {
    String vehicleNumber;
    String ownerName;

    vehicle(String vehicleNumber, String ownerName) {
        this.vehicleNumber = vehicleNumber;
        this.ownerName = ownerName;
    }

    void display() {
        System.out.println("Vehicle No: " + vehicleNumber);
        System.out.println("Owner Name: " + ownerName);
    }
}

